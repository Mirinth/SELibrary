﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS2450_Library_Software
{
    class ListInfo
    {
        public ListInfo()
        {

        }

        //Lists All Media
        public void ListAllMedia(List<Media> allBooks)
        {

        }

        //Lists A Single Person Books
        public void ListPatronsBooks(Patron person)
        {

        }

        //Lists All Overdue Books
        public void ListAllOverdueBooks(List<Media> allBooks)
        {

        }
    }
}

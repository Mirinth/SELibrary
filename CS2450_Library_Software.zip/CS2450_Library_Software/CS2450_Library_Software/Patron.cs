﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS2450_Library_Software
{
    class Patron
    {
        const int MAX_ADULT = 6;
        const int MAX_CHILD = 3;

        private PATRONTYPE pType;
        private string pName;
        private int pAge;
        private List<Media> mediaCheckoutOut;

        //Constructor For Patron
        public Patron(string name, int age, PATRONTYPE type)
        {
            pName = name;
            pAge = age;
            pType = type;
            mediaCheckoutOut = new List<Media>();
        }

        //Delete Media To Patron
        public void CheckInBook(Media checkIn)
        {

        }

        //Add Media to Patron
        public void CheckOutBook(Media checkout)
        {
            //Check Age and Amount
        }

        public PATRONTYPE PatronType
        {
            get { return pType; }
            set { pType = value; }
        }

        public string PatronName
        {
            get { return pName; }
            set { pName = value; }
        }

        public int PatronAge
        {
            get { return pAge; }
            set { pAge = value; }
        }

        public List<Media> PatronMedia
        {
            get { return mediaCheckoutOut; }
            set { mediaCheckoutOut = value; }
        }

        internal FileIO FileIO
        {
            get
            {
                throw new System.NotImplementedException();
            }
            set
            {
            }
        }

        public PATRONTYPE PATRONTYPE
        {
            get
            {
                throw new System.NotImplementedException();
            }
            set
            {
            }
        }
    }

    public enum PATRONTYPE { ADULT, CHILD };
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS2450_Library_Software
{
    class DateSimulator
    {
        DateTime date;

        public DateSimulator()
        {
            date = new DateTime();
        }

        //Move forward one day
        public void IncrementDay()
        {

        }

        //Move back one day
        public void DecrementDat()
        {

        }

        public DateTime GetDate()
        {
            return date;
        }
    }
}
